# AngularTask
Where we do full stack goodly
