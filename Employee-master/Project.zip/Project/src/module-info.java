/**
 * 
 */
/**
 * @author trainee
 *
 */
module Project {
	requires java.sql;
	requires java.xml;
}